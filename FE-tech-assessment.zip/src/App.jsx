import { ReactComponent as DownArrow } from "./assets/icons/down_arrow.svg";
import { ReactComponent as Checkmark } from "./assets/icons/checkmark.svg";
import "./App.scss";

const CURRENCIES = [
  { value: "USD", name: "America (United States) Dollars – USD" },
  { value: "EGP", name: "Egypt Pounds – EGP" },
  { value: "LKR", name: "Sri Lanka Rupees – LKR" },
  { value: "EUR", name: "Euro – EUR" },
];

function App() {
  return (
    <div className="App">
      <div className="Controls">
        <div className="FormField">
          <label className="Checkbox">
            <input
              type="checkbox"
              id="group-by-deal-owner"
              className="Checkbox_Input"
            />
            <div className="Checkbox_Box" aria-hidden="true">
              <Checkmark className="Checkbox_Icon" />
            </div>
            <span className="Checkbox_Label">Group By Deal Owner</span>
          </label>
        </div>
        <div className="FormField">
          <label htmlFor="currency" className="Label">
            Select Currency
          </label>
          <select
            id="currency"
            name="currency"
            className="FormField_Input FormField_Input-select"
          >
            {CURRENCIES.map(({ value, name }) => (
              <option key={value} value={value}>
                {name}
              </option>
            ))}
          </select>
          <DownArrow className="FormField_SelectArrow" aria-hidden="true" />
        </div>
      </div>
      <div className="Outuput"></div>
    </div>
  );
}

export default App;
