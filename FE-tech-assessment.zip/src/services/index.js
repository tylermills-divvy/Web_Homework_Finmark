import metadata from "./metadata.json";
import entries from "./entries.json";

export const dataTypes = /** @type {const} */ ({
  NUMBER: "NUMBER",
  DATE: "DATE",
  STRING: "STRING",
});

/** @typedef {dataTypes[keyof dataTypes]} DataType */

/**
 * @typedef {Array<{
 *   dataType: DataType;
 *   name: string;
 * }>} MetadataResponseData
 */

/**
 * @typedef {{
 *   id: string;
 *   fields: Array<{
 *     name: string;
 *     value?: string;
 *   }>
 * }} Entry
 */

/**
 * @typedef {{
 *   total: number;
 *   entries: Entry[]
 * }} EntitiesResponseData
 */

/** @type {(data: any, ms: number) => Promise<any>} */
const wait = (data, ms) =>
  new Promise((resolve) => window.setTimeout(() => resolve(data), ms));

const randomMs = (min = 0, max = 2000) => Math.random() * (max - min) + min;

/** @type {() => Promise<{ data: MetadataResponseData }>} */
export const getMetadata = () => wait(metadata, randomMs());

/** @type {() => Promise<{ data: EntitiesResponseData }>} */
export const getEntries = () => wait(entries, randomMs());
